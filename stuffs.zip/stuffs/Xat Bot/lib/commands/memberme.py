class memberme:
	def __init__(self,Socket,UserID):
		Socket.send('<c u="'+UserID+'" t="/e" />\0')