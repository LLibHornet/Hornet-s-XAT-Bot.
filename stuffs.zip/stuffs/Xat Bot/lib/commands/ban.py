class ban:
	def __init__(self,Socket,UserID,UserToBan):
		Socket.send('<c p="['+UserID+'] wanted me to ban you." u="'+UserToBan+'" t="/g3600" />\0')