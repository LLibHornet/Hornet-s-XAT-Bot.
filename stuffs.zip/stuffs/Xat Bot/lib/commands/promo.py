class promo:
	def __init__(self,Socket,ID):
		chat = ''
		json = loads(urlopen('http://www.xat.com/json/promo.php').read())
		if len(json['en']) == 1: Socket.send('<m u="'+ID+'" t="[English] Promoted Chats: '+json['en'][0]['n']+'" />\0')
		else: 
			for promo in range(0,len(json['en'])):	
				chat +=  json['en'][promo]['n'] + ' , '
			Socket.send('<m u="'+ID+'" t="[English] Promoted Chats: '+chat+'" />\0')