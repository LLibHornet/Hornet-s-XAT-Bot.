class lie:
	def __init__(self,Socket,ID):
		Answers = ['It looks to me as if that\'s a lie..','Wow..that actually is the truth','That is totally a lie.','Yes that\'s true!']
		Socket.send('<m u="'+ID+'" t="'+choice(Answers)+'" />\0')