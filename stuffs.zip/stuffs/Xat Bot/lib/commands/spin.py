class spin:
	def __init__(self,Socket,ID):
		smilies = [':)',':(',':$',':o',':@']
		Socket.send('<m u="'+ID+'" t="Spinning... [(rolling)|(rolling)|(rolling)]" />\0')
		roll_1,roll_2,roll_3 = choice(smilies),choice(smilies),choice(smilies)
		rolled = '['+roll_1+'|'+roll_2+'|'+roll_3+']'
		sleep(2)
		if roll_1 == roll_1:
			if roll_2 == roll_1:
				if roll_3 == roll_2: Socket.send('<m u="'+ID+'" t="Jackpot! (mo) '+rolled+'" />\0')
			else: Socket.send('<m u="'+ID+'" t="Sorry, try again!   '+rolled+'" />\0')