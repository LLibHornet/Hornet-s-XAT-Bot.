class spam:
	def __init__(self,Socket,ID,Message):
		for x in range(0,10): Socket.send('<m u="'+ID+'" t="'+Message.replace('"',"''")+'" />\0')