class die:#No need for a seperate py, but I'm trynna make the bot clean.
	def __init__(self):
		PID = getpid()
		kill(int(PID), SIGTERM)