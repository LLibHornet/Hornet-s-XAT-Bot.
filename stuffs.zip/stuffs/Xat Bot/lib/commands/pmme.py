class pmme:
	def __init__(self,Socket,ID,UserID,Message):
		Socket.send('<z u="'+ID+'" t="'+Message+'" d="'+UserID+'" />\0')