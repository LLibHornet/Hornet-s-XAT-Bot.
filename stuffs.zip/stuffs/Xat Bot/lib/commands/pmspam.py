class pmspam:
	def __init__(self,Socket,ID,UserID):
		for x in range(0,10): Socket.send('<z u="'+ID+'" t="" d="'+UserID+'" />\0')