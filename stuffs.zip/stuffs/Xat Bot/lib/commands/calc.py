class calc:
	def __init__(self,Socket,ID,Message):
		try:
			if '+' in Message:
				Numbers = Message.split('+')
				One, Two = int(Numbers[0]), int(Numbers[1])
				Answer = One + Two
				Socket.send('<m u="'+ID+'" t="'+str(Answer)+'" />\0')
			elif '-' in Message:
				Numbers = Message.split('-')
				One, Two = int(Numbers[0]), int(Numbers[1])
				Answer = One - Two
				Socket.send('<m u="'+ID+'" t="'+str(Answer)+'" />\0')
			elif '*' in Message:
				Numbers = Message.split('*')
				One, Two = int(Numbers[0]), int(Numbers[1])
				Answer = One * Two
				Socket.send('<m u="'+ID+'" t="'+str(Answer)+'" />\0')
			elif '/' in Message:
				Numbers = Message.split('/')
				One, Two = int(Numbers[0]), int(Numbers[1])
				Answer = One / Two
				Socket.send('<m u="'+ID+'" t="'+str(Answer)+'" />\0')
			else: Socket.send('<m u="'+ID+'" t="Unable to solve '+Message+'" />\0')
		except: Socket.send('<m u="'+ID+'" t="Unable to solve '+Message+'" />\0')