class yomamma:
	def __init__(self,Socket,Person,ID):
		url = urlopen('http://api.yomomma.info/').read()
		yomamma = loads(url)
		yomamma = Person + ', ' + yomamma['joke']
		Socket.send('<m u="'+ID+'" t="'+yomamma+'" />\0')