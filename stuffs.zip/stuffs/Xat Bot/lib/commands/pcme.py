class pcme:
	def __init__(self,Socket,ID,UserID,Message):
		Socket.send('<z u="'+ID+'" t="'+Message+'" d="'+UserID+'" s="2" />\0')