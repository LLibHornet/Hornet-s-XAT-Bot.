class acc:
	def __init__(self,Socket,ID,User):
		Opener = build_opener()
		Opener.addheaders = [('User-agent', 'Mozilla/5.0')]
		if(self.is_number(User)): Output = Opener.open('http://xat.me/web_gear/chat/profile.php?id='+User).read()
		else: Output = Opener.open('http://xat.me/web_gear/chat/profile.php?name='+User).read()
		Socket.send('<m u="'+ID+'" t="'+Output+'" />\0')
	def is_number(self, s):
		try:
			int(s)
			return True
		except ValueError:
			return False