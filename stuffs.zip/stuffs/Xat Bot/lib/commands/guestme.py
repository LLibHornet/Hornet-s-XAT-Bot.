class guestme:
	def __init__(self,Socket,UserID):
		Socket.send('<c u="'+UserID+'" t="/r" />\0')