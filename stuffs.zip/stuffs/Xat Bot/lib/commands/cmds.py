class cmds:
	def __init__(self,Socket,ID,UserID):
		Socket.send('<z u="'+ID+'" d="'+UserID+'" t="Command Page: http://hastebin.com/yuxivajaho.avrasm" />\0')