class insult:
	def __init__(self,Socket,ID,Target):
		url = urlopen('http://quandyfactory.com/insult/json').read()
		insult = loads(url)
		Socket.send('<m u="'+ID+'" t="'+Target+', '+insult['insult']+'" />\0')