class info:
	def __init__(self,Socket,ID,UserID):
		Socket.send('<z u="'+ID+'" t="I am a python bot written by Kondra! Go check out his FREE bot panel @ http://hastebin.com/isezuwuloz.avrasm" d="'+UserID+'" />\0')