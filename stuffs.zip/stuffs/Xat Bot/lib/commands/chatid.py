class chatid:
	def __init__(self,Socket,ID,Chat):
		Socket.send('<m u="'+ID+'" t="'+loads(urlopen('http://xat.com/web_gear/chat/roomid.php?d=' + Chat + '&v2').read())['id']+'" />\0')