class kick:
	def __init__(self,Socket,UserID,UserToKick):
		Socket.send('<c p="['+UserID+'] wanted me to kick you." u="'+UserToKick+'" t="/k" />\0')