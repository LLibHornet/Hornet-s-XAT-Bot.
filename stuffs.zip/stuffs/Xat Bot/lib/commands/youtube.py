class youtube:
	def __init__(self,Socket,ID,VideoToSearch):
		Load = urlopen('https://www.googleapis.com/youtube/v3/search?part=snippet&q=' + quote_plus(VideoToSearch) + '&key=AIzaSyBwBs83XSWHOlxIKrf7VvaE-AbIl_zqIbw&type=video&maxResults=1')
		Matches = list(set(re_findall('"videoId": "([A-Za-z0-9\-\_]+)"', Load.read())))
		
		if len(Matches) == 0: Socket.send('<m u="'+ID+'" t="No videos were found. :(" />\0')
		else:
			for Match in Matches: Socket.send('<m u="'+ID+'" t="http://www.youtube.com/watch?v='+Match+'" />\0')