class roll:
	def __init__(self,Socket,ID,User):
		Socket.send('<m u="'+ID+'" t="['+User+'] rolled a '+str(randint(1,6))+'" />\0')