class say:
	def __init__(self,Socket,ID,Message):
		Message = Message.replace('"',"''")
		Message = Message.replace('/',"_/")
		Message = Message.replace('#',"_#")
		Socket.send('<m u="'+ID+'" t="'+Message+'" />\0')