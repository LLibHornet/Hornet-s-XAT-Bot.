<?php
	if(empty($_POST['kon'])) 
	{
		echo 'Sorry, the bot panel is offline at this time. T.T   - Kondra.';
		header('Refresh: 5; url=index.php');
	}else{
		if(empty($_POST['chat'])) 
		{
			$chat = 'sqli';
			header('Refresh: 0.001; url=index.php');
		} else {
			$chatFolder = "./chats/".$_POST['chat'];
			if(!is_dir($chatFolder)){
				mkdir($chatFolder, 0755);
			}
		}
		if(empty($_POST['owner'])) 
		{
			$owner = '1344324240';
		} else {
			$owner = str_replace(" "," ",$_POST["owner"]);
		}
		if(empty($_POST['nick'])) 
		{
			$nick = 'Bot.py';
		} else {
			$nick = str_replace(" "," ",$_POST["nick"]);
		}
		if(empty($_POST['avatar'])) 
		{
			$avatar = '1667';
		} else {
			$avatar = str_replace(" ","_",$_POST["avatar"]);
		}
		if(empty($_POST['homepage'])) 
		{
			$homepage = 'http://xat.com/SQLi';
		} else {
			$homepage = str_replace(" ","_",$_POST["homepage"]);
		}
		if(empty($_POST['tickleMsg'])) 
		{
			$tickle = '/';
		} else {
			$tickle = str_replace(" "," ",$_POST["tickleMsg"]);
		}
		if(empty($_POST['welcomeMsg'])) 
		{
			$welcome = '/';
		} else {
			$welcome = str_replace(" "," ",$_POST["welcomeMsg"]);
		}
		if(empty($_POST['char'])) 
		{
			$char = '!';
		} else {
			$char = $_POST['char'];
		}
		
		$arr = array('chat' => $_POST['chat'], 'owner' => $owner, 'nick' => $nick, 'avatar' => $avatar, 'homepage' => $homepage, 'tickle' => $tickle, 'welcome' => $welcome, 'char' => $char);
		$lol = json_encode($arr);
		
		$init_txt = fopen('./chats/'.$_POST['chat'].'/chat.ini', "wb");
		fwrite($init_txt, $lol);
		fclose($init_txt);
		
		exec('python init.py -c '.$_POST['chat'].' &', $output);
		header('Refresh: 0.001; url=index.php');
	}
?>