<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Xat Bypass Bot</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="assets/css/stylesheet.css" rel="stylesheet" type="text/css">
	
	<script src="assets/js/jquery-1.11.1.min.js"></script>
	<script src="assets/js/jquery.mb.YTPlayer.js"></script>
</head>
<body background="assets/img/backgroundtest.gif">
	<nav class="navbar navbar-default navbar-fixed-top">
		<div class="container">
		<div class="navbar-header">
			<a class="navbar-brand">Xat Bot Panel</a>
			</div>
			
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav navbar-left">

			
								<li><a href="https://xatbot-kondraxat.c9users.io/bot/">Panel</a></li>	
			
				</ul>
			</div>
		</div>
		</nav>
				<br><br><br><br>
			<div class="block c3 tl" style="float: left;">
				<div class="heading"> Bot Commands </div>
				<table style="width: 99%">
					<h6><font color="red"/>*NOTE*</font> All users will be able to use the uverified + verified commands if "!verification" is turned off.</h6>
					<h5><b><u>Admin Commands:</b></u></h5>
					<h6><u>owner [ID here]</u> (Add someone into the owner array.)</h6>
					<h6><u>unowner [ID here]</u> (Remove someone from the owner array.)</h6>
					<h6>+ Every other command.</h6>
					<br>
					<h5><b><u>Owner Commands:</b></u></h5>
					<h6><u>verification on/off</u> (Enable & disable user verification to use commands.)</h6>
					<h6><u>verify [ID here]</u> (Verify a user to use commands.)</h6>
					<h6><u>unverify [ID here]</u> (Disable a user from using commands.)</h6>
					<h6><u>nf on/off</u> (Enable / disable Nofollow.)</h6>
					<h6><u>censor on/off</u> (Enable / disable cuss word kicking.)</h6>
					<h6><u>copy [ID here]</u> (Make the bot copy whatever the user says.)</h6>
					<h6><u>copy off</u> (Make the bot stop copying whoever you made it copy.)</h6>
					<h6><u>spam [Text here]</u> (Make the bot spam the chat with whatever text you input.)</h6>
					<h6><u>pmspam [ID here]</u> (Make the bot pm spam the user you input.)</h6>
					<h6><u>pcspam [ID here]</u> (Make the bot pc spam the user you input.)</h6>
					<h6><u>kick [ID here]</u> (Make the bot kick the user you input.)</h6>
					<h6><u>ban [ID here]</u> (Make the bot ban the user you input.)</h6>
					<h6><u>die</u> (Disconnects the bot.)</h6>
					<h6>+ All verified commands.</h6>
					<br>
					<h5><b><u>Verified Commands:</b></u></h5>
					<h6><u>say [Text here]</u> (Make the bot say whatever you want it to.)</h6>
					<h6><u>yell [Text here]</u> (Make the bot say whatever you want it to, in all caps.)</h6>
					<h6><u>roll</u> (Returns a dice number. 1-6)</h6>
					<h6><u>8ball (Question here)</u> (Make the bot [8ball] respond to your question.)</h6>
					<h6><u>insult (User here)</u> (Make the bot insult a user.)</h6>
					<h6><u>yomamma</u> (Returns a yomamma joke.)</h6>
					<h6><u>fact</u> (Make the bot say a random fact.)</h6>
					<h6><u>pmme [Text here]</u> (Make the bot pm you whatever you want it to.)</h6>
					<h6><u>pcme [Text here]</u> (Make the bot pc you whatever you want it to.)</h6>
					<h6><u>youtube [Text here]</u> (Make the bot post a video link to what you make it search.)</h6>
					<h6><u>chatid [Chat name here]</u> (Make the bot return the chat id for the chat you input.)</h6>
					<h6><u>acc [ID or Regname here]</u> (Make the bot return the id or regname for the user you input.)</h6>
					<h6><u>lie [Whatever you want to know is true or false here]</u> (Makes the bot tell you if it's true or false.)</h6>
					<h6><u>promo</u> (Returns the current English chats promoted.)</h6>
					<h6><u>spin</u> (Play slots using the bot.)</h6>
					<h6><u>guestme</u> (Make the bot make you a guest.)</h6>
					<h6><u>memberme</u> (Make the bot make you a member.)</h6>
					<h6><u>cmds</u> (Make the bot give the link to this page.)</h6>
					<br>
					<h6><b><u>Unverified Commands:</b></u></h5>
					<h6><u>info</u> (Make the bot give information about itself.)</h6>
					<br>
					<h6><b>More commands/functions will be added daily!</b></h6>
				</table>
			</div>
		</div>
<!-- <script type="text/javascript">document.getElementById('code').value = Math.floor(Math.random() * 9999999);</script> -->
<script src="/cache/cache.php?f=query.js"></script>
<script src="/cache/cache.php?f=script.js"></script>
<script src="assets/js/bootstrap.js" type="text/javascript"></script>
<script src="assets/js/custom.js" type="text/javascript"></script>
<script src="assets/js/smoothscroll.js" type="text/javascript"></script>
</body>
</html>
