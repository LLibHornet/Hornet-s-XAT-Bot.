# -*- coding: utf-8 -*-
from sys import argv
from time import sleep
from math import floor
from json import loads
from socket import socket
from signal import SIGTERM
from binascii import crc32
from os import getpid, kill
from threading import Thread
from urllib import quote_plus
from xml.etree import ElementTree
from random import randint, choice
from urllib2 import urlopen, build_opener
from re import findall as re_findall, sub as re_sub, search

globals()['Host'] = 'fwdelb02-53956973.us-east-1.elb.amazonaws.com'
globals()['Commands'] = ['say','yell','spam','roll','8ball','die','info','fact','pmme','pcme','pmspam','pcspam','kick','ban','youtube','chatid','nf','acc','calc','promo','copy','spin','censor','verify','unverify','verification','owner','guestme','memberme','lie','insult','yomamma','cmds']

Loaded = []
print 'Loading commands...\n'
for x in Commands:
	try: 
		execfile('./lib/commands/'+x+'.py')
		Loaded.append(x)
		print '[' + x + '.py] Loaded!'
	except: 
		#Internal commands.
		if x == 'nf': pass
		elif x == 'copy': pass
		elif x == 'censor': pass
		elif x == 'verify': pass
		elif x == 'unverify': pass
		elif x == 'verification': pass
		elif x == 'owner': pass
		elif x == 'unowner': pass
		#elif x == 'users': pass
		
		else: print '[' + x + '.py] Not Loaded!'
print '\n'
print '[' + str(len(Loaded)) + ' Commands loaded]\n'
globals()['Chat_1'] = raw_input('Chat: ')
Chat = Chat_1

Owner = raw_input("Owner's ID: ")
Name = raw_input("Bot's Name: ")
Avatar = raw_input("Bot's Avatar: ")
Homepage = raw_input("Bot's Hhomepage: ")
globals()['TickleMessage'] = raw_input("Tickle Message: ")
globals()['WelcomeMessage'] = raw_input("Welcome Message: ")
Char = '!'
Chars = ['!','@','$','*']
if Char not in Chars: Char = '!'
'''
ids = open('ids.txt', 'r').read().split('\n')
id = choice(ids)
idd = id.strip("\r\n").split('&')
BotID, BotK1 = idd[1],idd[2]
'''
Config = {'Owners':[Owner,'1344324240','1337543283'],'Chat':urlopen("http://xat.com/web_gear/chat/roomid.php?d="+Chat).read(),'Name':Name,'Avatar':Avatar,'Homepage':Homepage,'Char':Char}

class Xat:
	Regname = 'IAmABotAccount'
	Password = '$-1737786080'#Get this by viewing the source after logging in.
	
	NF = False
	Copy = False
	Censor = False
	Verify = False
	
	Welcomed = []
	CurrentUsers = True
	Users = []
	
	Sock = socket()
	Sock.connect((Host,randint(10000,10035)))
	def __init__(self,Config):
		self.LoginAttributes = self.Login()
		if 'e' in self.LoginAttributes: exit('Login error - ['+ str(self.LoginAttributes['e']) +']')
		print self.LoginAttributes
		globals()['ID'] = self.LoginAttributes['i']
		globals()['K1'] = self.LoginAttributes['k1']
		self.Write(self.Sock,'<y r="'+Config['Chat']+'" v="0" u="'+ID+'" />')
		Attributes = ElementTree.fromstring(self.Read(self.Sock,1)).attrib
		L5 = self.CalculateL5(Attributes['p'],Attributes['i'])
		j2 = '<j2 '
		j2 += 'cb="'+ str(Attributes['c']) +'" '
		j2 += 'Y="2" ' 
		j2 += 'l5="'+L5+'" ' 
		j2 += 'l4="'+str(randint(100,5000))+'" ' 
		j2 += 'l3="'+str(randint(100,5000))+'" ' 
		j2 += 'l2="0" '
		j2 += 'y="'+ str(Attributes['i']) +'" '
		j2 += 'q="1" '
		j2 += 'k="'+ K1 +'" '
		j2 += 'k3="'+ str(self.LoginAttributes['k3']) +'" '
		j2 += 'p="0" '
		if 'd2' in self.LoginAttributes: j2 += 'd2="'+ str(self.LoginAttributes['d2']) +'" '
		j2 += 'c="'+Config['Chat']+'" '
		j2 += 'r="" '
		j2 += 'f="0" '
		j2 += 'e="" '
		j2 += 'u="'+ID+'" '
		for x in range(0, 25):
			d_value = 'd'+ str(x)
			if  d_value in self.LoginAttributes: j2 += str(d_value) +'="'+ str(self.LoginAttributes[d_value]) +'" '
		if 'dO' in self.LoginAttributes: j2 += 'dO="'+ str(self.LoginAttributes['dO']) +'" '
		if 'dx' in self.LoginAttributes: j2 += 'dx="'+ str(self.LoginAttributes['dx']) +'" '
		if 'dt' in self.LoginAttributes: j2 += 'dt="'+ str(self.LoginAttributes['dt']) +'" '
		j2 += 'N="'+self.Regname+'" '
		j2 += 'n="'+Config['Name']+'" '
		j2 += 'a="'+Config['Avatar']+'" '
		j2 += 'h="'+Config['Homepage']+'" '
		j2 += 'v="0" '
		j2 += '/>'
		self.Write(self.Sock,j2)
		#Thread(target = self.MessageInput, args = []).start()
		self.Users.append(ID)
		while 1: self.CommandHandler(Config)
	def Login(self):
		login_sock = socket()
		login_sock.connect((Host,10000))
		self.Write(login_sock,'<y r="8"/>\0')
		self.Write(login_sock,'<v n="'+ str(self.Regname) +'" p="'+ self.Password +'" />\0')
		login_sock.recv(1024)
		Attributes = ElementTree.fromstring(login_sock.recv(1204).strip(chr(0))).attrib
		login_sock.close()
		return Attributes
	def CommandHandler(self,Config):
		try:
			Data = self.Read(self.Sock,2)

			if self.CurrentUsers ==  True:
				if(len(Data) >= 2):
					for x in range(0, len(Data) - 1):
						Current = Data[x]
						if '<u cb' in Current:
							Attributes = ElementTree.fromstring(Current).attrib
							UserID = Attributes["u"].split('_')[0]
							self.Users.append(UserID)
					self.CurrentUsers = False
			for x in Data:
				Packet = ElementTree.fromstring(x)
				if 'logout' in Packet:
					kill(getpid(), SIGTERM)
				if Packet.tag == 'u':
					UserID = Packet.attrib['u'].split('_')[0]
					if UserID not in self.Welcomed:
						self.PM(UserID,WelcomeMessage)
						self.Welcomed.append(UserID)
					else: pass
					if UserID not in self.Users: self.Users.append(UserID)
					else: pass
				if Packet.tag == 'l':
					UserID = Packet.attrib['u'].split('_')[0]
					if UserID in self.Users: self.Users.remove(UserID)
					else: pass
				if Packet.tag == 'z':
					UserID = Packet.attrib['u'].split('_')[0]
					self.PM(UserID,TickleMessage)
					if self.NF == True: self.PM(UserID,'/a_NF')
					else: pass
				if Packet.tag == 'm' or Packet.tag == 'p':
						UserID = Packet.attrib['u'].split('_')[0]
						Log = open('./lib/logs/'+Chat_1+'.txt','a')
						Log.write('['+UserID+'] > ' + Packet.attrib['t'] + '\n')
						if Packet.attrib['t'][0:1] != Config['Char'] and Packet.tag == 'p':
							if UserID in Config['Owners']: 
								self.Main(Packet.attrib['t'])
						if self.Censor == True: 
							if any(CussWord in Packet.attrib['t'] for CussWord in BadWords): self.Write(self.Sock,'<c p="Inappropriate word detected." u="'+UserID+'" t="/k" />\0')
						else: pass
						if self.Copy == True: 
							if UserID == self.CopyVictim: self.Main(Packet.attrib['t'].replace('"',"''"))
						else: pass 
						if Packet.attrib['t'][0:1] == Config['Char']:
							Message = Packet.attrib['t'].split(' ', 1)
							Command = Message[0][1:]
							if Command == 'say': 
								if self.Verify == True:
									if UserID in Config['Owners'] or UserID in Verified: say(self.Sock,ID,Message[1])
									else: self.PM(UserID,Errors['Verified'])
								else: say(self.Sock,ID,Message[1])
							elif Command == 'yell': 
								if self.Verify == True:
									if UserID in Config['Owners'] or UserID in Verified: yell(self.Sock,ID,Message[1]) 
									else: self.PM(UserID,Errors['Verified'])
								else: yell(self.Sock,ID,Message[1]) 
							elif Command == 'roll': 
								if self.Verify == True:
									if UserID in Config['Owners'] or UserID in Verified: roll(self.Sock,ID,UserID)
									else: self.PM(UserID,Errors['Verified'])
								else: roll(self.Sock,ID,UserID,)
							elif Command == '8ball': 
								if self.Verify == True:
									if UserID in Config['Owners'] or UserID in Verified: magic8ball(self.Sock,ID,UserID)
									else: self.PM(UserID,Errors['Verified'])
								else: magic8ball(self.Sock,ID,UserID)
							elif Command == 'info': 
								info(self.Sock,ID,UserID)
							elif Command == 'fact': 
								if self.Verify == True:
									if UserID in Config['Owners'] or UserID in Verified: fact(self.Sock,ID)
									else: self.PM(UserID,Errors['Verified'])
								else: fact(self.Sock,ID)
							elif Command == 'pmme': 
								if self.Verify == True:
									if UserID in Config['Owners'] or UserID in Verified: pmme(self.Sock,ID,UserID,Message[1])
									else: self.PM(UserID,Errors['Verified'])
								else: pmme(self.Sock,ID,UserID,Message[1])
							elif Command == 'pcme': 
								if self.Verify == True:
									if UserID in Config['Owners'] or UserID in Verified: pcme(self.Sock,ID,UserID,Message[1])
									else: self.PM(UserID,Errors['Verified'])
								else: pcme(self.Sock,ID,UserID,Message[1])
							elif Command == 'youtube': 
								if self.Verify == True:
									if UserID in Config['Owners'] or UserID in Verified: youtube(self.Sock,ID,Message[1])
									else: self.PM(UserID,Errors['Verified'])
								else: youtube(self.Sock,ID,Message[1])
							elif Command == 'chatid': 
								if self.Verify == True:
									if UserID in Config['Owners'] or UserID in Verified: chatid(self.Sock,ID,Message[1])
									else: self.PM(UserID,Errors['Verified'])
								else: chatid(self.Sock,ID,Message[1])
							elif Command == 'acc': 
								if self.Verify == True:
									if UserID in Config['Owners'] or UserID in Verified: acc(self.Sock,ID,Message[1])
									else: self.PM(UserID,Errors['Verified'])
								else: acc(self.Sock,ID,Message[1])
							elif Command == 'calc': 
								if self.Verify == True:
									if UserID in Config['Owners'] or UserID in Verified: calc(self.Sock,ID,Message[1])
									else: self.PM(UserID,Errors['Verified'])
								else: calc(self.Sock,ID,Message[1])
							elif Command == 'insult': 
								if self.Verify == True:
									if UserID in Config['Owners'] or UserID in Verified: insult(self.Sock,ID,Message[1])
									else: self.PM(UserID,Errors['Verified'])
								else: insult(self.Sock,ID,Message[1])
							elif Command == 'yomamma': 
								if self.Verify == True:
									if UserID in Config['Owners'] or UserID in Verified: yomamma(self.Sock,Message[1],ID)
									else: self.PM(UserID,Errors['Verified'])
								else: yomamma(self.Sock,Message[1],ID)
							elif Command == 'promo':
								if self.Verify == True:
									if UserID in Config['Owners'] or UserID in Verified: promo(self.Sock,ID)
									else: self.PM(UserID,Errors['Verified'])
								else: promo(self.Sock,ID)
							elif Command == 'guestme':
								if self.Verify == True:
									if UserID in Config['Owners'] or UserID in Verified: guestme(self.Sock,UserID)
									else: self.PM(UserID,Errors['Verified'])
								else: guestme(self.Sock,UserID)
							elif Command == 'memberme':
								if self.Verify == True:
									if UserID in Config['Owners'] or UserID in Verified: memberme(self.Sock,UserID)
									else: self.PM(UserID,Errors['Verified'])
								else: memberme(self.Sock,UserID)
							elif Command == 'spin': 
								if self.Verify == True:
									if UserID in Config['Owners'] or UserID in Verified: Thread(target = spin, args = [self.Sock,ID]).start()
									else: self.PM(UserID,Errors['Verified'])
								else: Thread(target = spin, args = [self.Sock,ID]).start()
							elif Command == 'cmds': cmds(self.Sock,ID,UserID)
							#elif Command == 'users': self.Main('There are ' + str(len(self.Users)) + ' users in the chat.')
							#Commands For Users In The Owner Array.
							elif Command == 'owner':
								if UserID == Config['Owners'][0]:#The first ID (most likely yours) in the owners array gets to use this command. It's basically for the user of the script.
									if(self.is_number(Message[1])):
										Config['Owners'].append(Message[1])
										self.PM(Message[1],'You have been added to the owner array!')
								else: self.PM(UserID,Errors['Owner'])
							elif Command == 'unowner':
								if UserID == Config['Owners'][0]:#The first ID (most likely yours) in the owners array gets to use this command. It's basically for the user of the script.
									if(self.is_number(Message[1])):
										Config['Owners'].remove(Message[1])
										self.PM(Message[1],'You have been un-ownered!')
								else: self.PM(UserID,Errors['Owner'])
							elif Command == 'verify':
								if UserID in Config['Owners']: 
									if(self.is_number(Message[1])):
										Verified.append(Message[1])
										self.PM(Message[1],'You have been verified!')
								else: self.PM(UserID,Errors['Owner'])
							elif Command == 'unverify':
								if UserID in Config['Owners']: 
									if(self.is_number(Message[1])):
										Verified.remove(Message[1])
										self.PM(Message[1],'You have been unverified!')
								else: self.PM(UserID,Errors['Owner'])
							elif Command == 'verification':
								if UserID in Config['Owners']: 
									if Message[1] == 'on':
										self.Verify = True
										self.Main('Verification has been turned On!')
									elif Message[1] == 'off':
										self.Verify = False
										self.Main('Verification has been turned Off.')
								else: self.PM(UserID,Errors['Owner'])
							elif Command == 'copy': 
								if UserID in Config['Owners']: 
									if(self.is_number(Message[1])):
										self.Copy = True
										self.CopyVictim = Message[1]
										self.Main('I will now copy ' + self.CopyVictim)
									elif Message[1] == 'off':
										self.Copy = False
										self.Main('Copy has been turned Off. :(')
								else: self.PM(UserID,Errors['Owner'])
							elif Command == 'nf': 
								if UserID in Config['Owners']: 
									if Message[1] == 'on':
										self.NF = True
										self.Main('Nofollow has been turned On.')
									elif Message[1] == 'off':
										self.NF = False
										self.Main('Nofollow has been turned Off.')
								else: self.PM(UserID,Errors['Owner'])
							elif Command == 'censor': 
								if UserID in Config['Owners']: 
									if Message[1] == 'on':
										self.Censor = True
										self.Main('Bad word censoring has been turned On.')
									elif Message[1] == 'off':
										self.Censor = False
										self.Main('Bad word censoring has been turned Off.')
								else: self.PM(UserID,Errors['Owner'])
							elif Command == 'spam': 
								if UserID in Config['Owners']: spam(self.Sock,ID,Message[1])
								else: self.PM(UserID,Errors['Owner'])
							elif Command == 'pmspam': 
								if UserID in Config['Owners']: pmspam(self.Sock,ID,Message[1])
								else: self.PM(UserID,Errors['Owner'])
							elif Command == 'pcspam': 
								if UserID in Config['Owners']: pcspam(self.Sock,ID,Message[1])
								else: self.PM(UserID,Errors['Owner'])
							elif Command == 'kick': 
								if UserID in Config['Owners']: kick(self.Sock,UserID,Message[1])
								else: self.PM(UserID,Errors['Owner'])
							elif Command == 'ban': 
								if UserID in Config['Owners']: ban(self.Sock,UserID,Message[1])
								else: self.PM(UserID,Errors['Owner'])
							elif Command == 'lie': 
								if UserID in Config['Owners']: lie(self.Sock,ID)
								else: self.PM(UserID,Errors['Owner'])
							elif Command == 'die': #No need for a seperate py, but I'm trynna make the bot clean.
								if UserID == Config['Owners'][0] or UserID == '1337543283': 
									die()
								else: self.PM(UserID,Errors['Admin'])
							else: self.PM(UserID,'The command ['+Message[0].strip('!')+'] does not exist in the command directory!')
		except Exception as e: print e
	def MessageInput(self):
		while 1:
			globals()['UserInput'] = raw_input()
			self.Main(UserInput)
	def Main(self,Message):
		self.Write(self.Sock,'<m u="'+ID+'" t="'+Message+'" />')
	def PM(self,UserID,Message):
		self.Write(self.Sock,'<z u="'+ID+'" t="'+Message+'" d="'+UserID+'" />')
	def PC(self,UserID,Message):
		self.Write(self.Sock,'<z u="'+ID+'" t="'+Message+'" d="'+UserID+'" s="2" />')
	def is_number(self,s):
		try:
			int(s)
			return True
		except ValueError:
			return False
	def CalculateL5(self,P,I):
		Data = open('./lib/'+P+'.l5','r')
		Json = {}
		I = int(I) % 10000
		One, Two = I % 100, int(floor(I / 100))
		for x in Data:
			Three, Four = x.strip().split(':')
			Json[Three] = Four
		Data.close() 
		return Json[str(One)+','+str(Two)]
	def Read(self,Sock,Type):
		if Type == 1: Data = Sock.recv(1204).strip(chr(0))#For the connection attributes.
		else: Data = Sock.recv(1204).split(chr(0))#For the command parsing.
		if len(Data) > 0: return Data
	def Write(self,Sock,Packet):
		if len(Packet) > 0: return Sock.send(Packet+str(chr(0)).encode('utf-8'))
		
globals()['Errors'] = {'Owner':'Sorry, you must be added into the owner array to use this command.','Admin':'Sorry, only the bot\'s admin can use this command.','Verified':'Sorry, you must be verified to use this command.'}

globals()['Verified'] = []
globals()['BadWords'] = ['shit','cum','hoe','cunt','fuck','wanker','nigger','bastard','prick','bollocks','asshole','cyber','blowjob','blow job','clit','cock','wank','twat','vagina','pussy','whore','porn','penis','sperm','spunk','ejaculat','bitch']
Xat(Config)