$(document).ready(function() {
	$('[data-toggle="tooltip"]').tooltip();
	$('.player').mb_YTPlayer();

	$(window).load(function() {
        setTimeout(function() {
             $('body').addClass('loaded');
        }, 500);
    });
    
	$(window).scroll(function(event) {
		var scroll = $(window).scrollTop();
		if (scroll >= 100) {
			$('.to-top').slideDown();
		} else {
			$('.to-top').slideUp();
		}
	});

	$('.to-top').click(function(e) {
		e.preventDefault();
		var target = this.hash;
		var $target = $(target);
		$('html, body').stop().animate({
			'scrollTop' : 0
		}, 900, 'swing');
	})

});