<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Xat Bypass Bot</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="assets/css/stylesheet.css" rel="stylesheet" type="text/css">
	
	<script src="assets/js/jquery-1.11.1.min.js"></script>
	<script src="assets/js/jquery.mb.YTPlayer.js"></script>
</head>
<body background="assets/img/backgroundtest.gif">
	<nav class="navbar navbar-default navbar-fixed-top">
		<div class="container">
		<div class="navbar-header">
			<a class="navbar-brand">Xat Bot Panel</a>
			</div>
			
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav navbar-left">

			
								<li><a href="https://xatbot-kondraxat.c9users.io/bot/commands.php">Command Page</a></li>

			
				</ul>
			</div>
		</div>
		</nav>
				<br><br><br><br>
		﻿
		<div style="width: 100%;text-align: center;">
			<div class="block c3 tl" style="float: left;">
				<div class="heading"> Bot Configuration ⇣ </div>
				<table style="width: 99%">
					<form action="connect.php" method="post">
						<input type="hidden" name="cmd" value="login" />
						<tr> <td class="tl"> Chat Room</td> <td> <input style="width: 100%" type="text" name="chat" placeholder="The chat's NAME, not link. [Ex: Social]" /> </td> </tr>
						<!-- <tr> <td class="tl"> Chat Password</td> <td> <input style="width: 100%" type="text" name="pass" placeholder="For main owner. You can leave this blank." /> </td> </tr> -->
						<tr> <td class="tl"> Owner's ID </td> <td> <input style="width: 100%" type="text" name="owner" placeholder="Bot Owner's ID (NOT REGNAME) [EG: 1337543283]" </td> </tr>
						<tr> <td class="tl"> Bot's Name </td> <td> <input style="width: 100%" type="text" name="nick" placeholder="The bot's display name [EG: Bot.py]" /> </td> </tr>
						<tr> <td class="tl"> Bot's Avatar </td> <td> <input style="width: 100%" type="text" name="avatar" placeholder="The bot's avatar (number or url) [EG: 227]" /> </td> </tr>
						<tr> <td class="tl"> Bot's Homepage </td> <td> <input style="width: 100%" type="text" name="homepage" placeholder="The bot's homepage url [EG: xat.com/SQLi]" /> </td> </tr>
						<tr> <td class="tl"> Tickle Message </td> <td> <input style="width: 100%" type="text" name="tickleMsg" placeholder="Click Message [EG: You tickled me!]" /> </td> </tr>
						<tr> <td class="tl"> Welcome Message </td> <td> <input style="width: 100%" type="text" name="welcomeMsg" placeholder="Welcome Message [EG: Welcome to the chat!]" /> </td> </tr>
						<tr> <td class="tl"> Command Char </td> <td> <input style="width: 100%" type="text" name="char" placeholder="Command handler [!, @, $, or *]" /> </td> </tr>
						<tr> <td class="tl"></td> <td> <input style="width: 100%" type="hidden" name="kon" value="1" /> </td> </tr>
						<!-- <tr> <td class="tl"></td> <td> <input style="width: 100%" type="hidden" name="code" id="code" /> </td> </tr> -->
						<tr> <td colspan="2"> <input type="submit" value="Connect Bot" class="fr" /> </td> </tr>
					</form>
				</table>
			</div>
			
			<div class="block c3 tl" style="float: left;">
				<div class="heading"> Welcome to my xat bot panel. </div>
				<table style="width: 99%">
					<h5>Developed by <u>Kondra.</u></h5>
					<h6><u>My Paypal Email:</u> <i><b><font color="red">xkondra@gmail.com</font></b></i> (Donate for more awesome stuff ^-^)</h6>
					<h6>This bot does <b><font color="red">NOT</font></b> require the bot power. Just fill out the fields and hit "Connect Bot". To disconnect the bot, just type the command char + "die" (without the quotes) in chat. EG: !die (You have to be the bot's main owner)</h6>
					<h5>My xat account(s): <b><font color="red">ripzuhnny (1337543283)  | kondrathegod (1344324240)</font></b></h5>
					<h5>    - <font color="red">Kondra</font>.</b></h5>
				</table>
			</div>
		</div>
<!-- <script type="text/javascript">document.getElementById('code').value = Math.floor(Math.random() * 9999999);</script> -->
<script src="/cache/cache.php?f=query.js"></script>
<script src="/cache/cache.php?f=script.js"></script>
<script src="assets/js/bootstrap.js" type="text/javascript"></script>
<script src="assets/js/custom.js" type="text/javascript"></script>
<script src="assets/js/smoothscroll.js" type="text/javascript"></script>
</body>
</html>
