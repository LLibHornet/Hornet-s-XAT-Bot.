 # -*- coding: utf-8 -*-
 #Coded by Kondra.
import os
import sys
import math
import time
import socks
import socket
import random
import urllib2
import winsound
import threading
from Tkinter import *
from os import system
from threading import Thread
import xml.etree.ElementTree as xmlParse
globals()['CustomID'] = True
if CustomID:
	globals()['ID'] = '1501192859'
	globals()['K1'] = '7947ed1970558b01f700'
else:
	Auser3 = urllib2.urlopen('http://xat.com/web_gear/chat/auser3.php').read()
	globals()['ID'], globals()['K1'], globals()['K2'] = Auser3.split('&')[1].split('=')[1].strip('_'), Auser3.split('&')[2].split('=')[1], Auser3.split('&')[3].split('=')[1]
system('title xKonClient[Client Xat Bot]')
class xKonClient:
	def __init__(self):
		self.Proxy = ''#This is mainly for unbanning yourself. Leave blank if you're not going to use one.
		if self.Proxy != '':
			self.Proxy2 = self.Proxy.split(':')
			self.IP = self.Proxy2[0]
			self.Port = self.Proxy2[1]
			self.UseProxy = True
		else:
			self.UseProxy = False
		self.Sounds = True#Change to True to enable custom chat sounds. Change to False to disable them.
		print("--------------------------")
		print("xKonClient[Client Xat Bot]")
		print("--------------------------\n\n")
		self.Chat_1 = raw_input("-Chat (Name, not ID) > ")
		self.Name = raw_input("-Name | Nick > ")
		self.Avatar = raw_input("-Avatar | Picture > ")
		self.Homepage = raw_input("-Homepage | Home Link > ")
		print("\n")
 		
		self.Host = 'fwdelb02-53956973.us-east-1.elb.amazonaws.com'
		self.Chat_2 = urllib2.urlopen('http://xat.com/' + self.Chat_1).read()
		self.Chat = self.getBetween(self.Chat_2,'flashvars="id=','&')
		self.Log = 'log.txt'
		self.Messages = 0
		self.ConnectedUsers = 0
		self.UsersInChat = []
		self.Window = Tk()
		self.Window.iconbitmap('icons/windowIcon.ico')
		self.Window.geometry("505x481")
		self.Window.wm_title("http://xat.com/chat" + self.Chat + " (" + self.Chat_1 + ")")
		self.Window2 = Canvas(self.Window, width=710, height=380)
		
		self.Bar_1 = self.Window2.create_rectangle(1000, 20, 0, 300)
		self.Bar_2 = self.Window2.create_rectangle(500, 20, 0, 1000)
		
		#self.Send = Button(self.Window, text="Clear Chat", command = self.ClearMessages)
		#self.Send.pack(side="bottom", fill='both', expand=False, padx=9, pady=4)
		self.Refresh = Button(self.Window, text="Send", command = self.SendMessage)
		self.Refresh.pack(side="bottom", fill='both', expand=False, padx=9, pady=4)
		
		self.UserID = Entry(self.Window, bd = 5)
		self.UserID.pack(side="top", fill='both', expand=True, padx = 4, pady = 4)
		
		self.menu = Menu(self.Window)
		self.Window.config(menu=self.menu)
		self.UserOptions = Menu(self.menu,tearoff=False)
		self.menu.add_cascade(label="User Options (Menu)", menu=self.UserOptions)
		self.UserOptions.add_command(label="Ban",command = self.ban)
		self.UserOptions.add_command(label="Kick",command = self.kick)
		self.UserOptions.add_command(label="Make Guest",command = self.makeGuest)
		self.UserOptions.add_command(label="Make Member",command = self.makeMember)
		self.UserOptions.add_command(label="Make Moderator",command = self.makeModerator)
		#self.Send.config( height = 4, width = 5 )
		self.UserInput = Label( self.Window, text="Kondra's xat client")
		self.Input = Entry(self.Window, bd = 5)
		self.UserInput.pack()	
		self.Input.pack(side="bottom", fill='both', expand=True, padx = 4, pady = 4)
		self.Respond = Text(self.Window, height = 4, width = 35, background="grey", foreground="white")
		self.Respond.pack(side="left", fill='both', expand=True, padx = 4, pady = 4)
		self.Connectlist = Text(self.Window, height = 6, width = 25, background="grey", foreground="white")
		self.Connectlist.pack(anchor=CENTER, fill='both', expand=True, padx = 4, pady = 4)
		self.Connectlist.insert(END, "-------------------------\n")
		self.Connectlist.insert(END, "[Connection Log]\n")
		self.Connectlist.insert(END, "-------------------------\n")
		self.Userlist = Text(self.Window, height = 6, width = 25, background="grey", foreground="white")
		self.Userlist.pack(side="right", fill='both', expand=True, padx = 4, pady = 4)
		self.Userlist.insert(END, "-------------------------\n")
		self.Userlist.insert(END, "[Userlist]\n")
		self.Userlist.insert(END, "-------------------------\n")
		self.Userlist.insert(END, "*[Client]" + self.Name + "\n")
		self.Send = Button(self.Window, text="Send", padx = 10, pady = 4, command = self.SendMessage)
		self.Window2.pack()
		self.Connection()
		mainloop()
	def Ranksound(self):
		winsound.PlaySound('sounds/rank.wav', winsound.SND_FILENAME)
	def Messagesound(self):
		winsound.PlaySound('sounds/message.wav', winsound.SND_FILENAME)
	def Kicksound(self):
		winsound.PlaySound('sounds/kick.wav', winsound.SND_FILENAME)
	def Bansound(self):
		winsound.PlaySound('sounds/ban.wav', winsound.SND_FILENAME)
	def Connectedsound(self):
		winsound.PlaySound('sounds/connected.wav', winsound.SND_FILENAME)
	def makeGuest(self):
		if self.Sounds == True: threading.Thread(target=self.Ranksound,args=()).start()
		else: pass
		self.Sock.send('<c u="'+self.UserID.get()+'" t="/r" />\0')
		try:
			self.UserID.delete(0, END)
		except: pass
	def makeMember(self):
		if self.Sounds == True: threading.Thread(target=self.Ranksound,args=()).start()
		else: pass
		self.Sock.send('<c u="'+self.UserID.get()+'" t="/e" />\0')
		try:
			self.UserID.delete(0, END)
		except: pass
	def makeModerator(self):
		if self.Sounds == True: threading.Thread(target=self.Ranksound,args=()).start()
		else: pass
		self.Sock.send('<c u="'+self.UserID.get()+'" t="/m" />\0')
		try:
			self.UserID.delete(0, END)
		except: pass
	def kick(self):
		if self.Sounds == True: threading.Thread(target=self.Kicksound,args=()).start()
		else: pass
		self.Sock.send('<c p="^-^" u="'+self.UserID.get()+'" t="/k" />\0')
		try:
			self.UserID.delete(0, END)
		except: pass
	def ban(self):
		if self.Sounds == True: threading.Thread(target=self.Bansound,args=()).start()
		else: pass
		self.Sock.send('<c p="^-^" u="'+self.UserID.get()+'" t="/g3600" />\0')
		try:
			self.UserID.delete(0, END)
		except: pass
	def ClearMessages(self):
		self.Respond.delete(1.0, END)
	def Connection(self):
		try:
			if self.UseProxy == True:
				self.Sock = socks.socksocket(socket.AF_INET, socket.SOCK_STREAM)
				self.Sock.setproxy(socks.PROXY_TYPE_SOCKS5,self.IP,self.Port)
				self.Sock.settimeout(10)
			else: pass
			self.Sock = socket.socket()
			self.Sock.connect((self.Host,10003))
			Handshake = [
				'<y ',
				'r="'+self.Chat+'" ',
				'm="1" ',
				'u="'+ID+'" ',
				'/>\0'
			]
			Handshake = ''.join(Handshake)
			Handshake = str(Handshake).strip("'")
			self.Sock.send(str(Handshake))
			#self.Packets = Label(self.Window, text="[Server] " + self.Data)
			#self.Packets.pack()
			self.Attributes = xmlParse.fromstring(self.Sock.recv(1024).strip(chr(0))).attrib
			#print(self.Attributes)
			self.l5 = self.getL5()
			j2 = [
				'<j2 ',
				'cb="'+self.Attributes['c']+'" ',
				'Y="2" ',
				'l5="'+self.l5+'" ',
				'l4="'+str(random.randint(1000,5000))+'" ',
				'l3="'+str(random.randint(1000,5000))+'" ',
				'l2="0" ',
				'y="'+self.Attributes['i']+'" ',
				'k="'+K1+'" ',
				'k3="0" ',
				'p="0" ',
				'c="'+self.Chat+'" ',
				'f="0" ',
				'u="'+ID+'" ',
				'd0="0" ',
				'd1="1500007700" ',
				'n="'+self.Name+'" ',
				'a="'+self.Avatar+'" ',
				'h="'+self.Homepage+'" ',
				'v="0" ',
				'/>\0'
			]
			j2 = ''.join(j2)
			j2 = str(j2).strip("'")
			self.Sock.send(str(j2))
			print("--------------------------------")
			print("> Connected on " + self.Host + "!")
			print("--------------------------------")
			if self.Sounds == True:	threading.Thread(target=self.Connectedsound,args=()).start()
			else: pass
			print("Any PM's or PC's Sent To The Client Bot Will Be Showed Below.\n")
			threading.Thread(target=self.Read,args=()).start()
		except: 
			print("--------------------------")
			print("> Failed To Connect!")
			print("--------------------------")
			time.sleep(10)
			sys.exit()
	def Read(self):
		while self.Sock:
			try:
				self.Data = self.Sock.recv(4096)
				#print(self.Data)
				if '<logout' in self.Data: self.Connection()
				else: pass
				if '<u' in self.Data:
					xml = xmlParse.fromstring(self.Data.strip('\0'))
					user = xml.attrib['n']
					user_1 = user.split('(')
					name = user_1[0]
					if name not in self.UsersInChat:
						if name != '':
							self.Userlist.insert(END, name + "\n")
							self.UsersInChat.append(name)
						else: pass
					else: pass
					if self.ConnectedUsers > 2:
						self.ConnectedUsers = 0
					else: self.Connectlist.insert(END, "[" +  user + "] has connected!\n\n")
				if '<l' in self.Data: pass
				if '<z' in self.Data:
					xml = xmlParse.fromstring(self.Data.strip('\0'))
					user = xml.attrib['u']
					follow = [
						'<z ',
						'd="'+user+'" ',
						'u="'+ID+'" ',
						't="/a_NF" ',
						'/>\0'
					]
					follow = ''.join(follow)
					follow = str(follow).strip("'")
					self.Sock.send(str(follow))
				if '<p' in self.Data:
					xml = xmlParse.fromstring(self.Data.strip('\0'))
					user = xml.attrib['u']
					message = xml.attrib['t']
					if 'RTypeOff' in message: pass
					elif 'RTypeOn' in message: pass
					else: print('[Received PM or PC] From [' + user + '] Message > ' + message +"\n")
				if '<m' in self.Data:
					xml = xmlParse.fromstring(self.Data.strip('\0'))
					user = xml.attrib['u']
					UserMessage = xml.attrib['t']
					Argument  = UserMessage.split(' ',1)
					Command = Argument[0]
					try:
						user2 = user.split('_')
						user = user2[0]
					except: pass
					message = xml.attrib['t']
					if 'RTypeOff' in message: pass
					elif 'RTypeOn' in message: pass
					elif '/u' in message: pass
					elif '/m' in message: pass
					elif '/s' in message: pass
					elif '/p' in message: pass
					elif '/d5' in message: pass
					elif '/d10' in message: pass
					elif '/d15' in message: pass
					else: 
						if self.Sounds == True:	threading.Thread(target=self.Messagesound,args=()).start()
						else: pass
						if len(self.Input.get()) > 10:
							self.Respond.insert(END, "[" + user + "]: " + message + "\n\n")
						else: self.Respond.insert(END, "[" + user + "]: " + message + "\n\n")
						Writer2 = open('log.txt','a')
						Writer2.write("[" + user + "] > " + message + "\n")
						Writer2.close()
					self.Messages += 1
					if self.Messages > 10:
						self.Messages = 0
						self.Respond.delete(1.0, END)
			except: pass
	def SendMessage(self):
		self.Sock.send('<m u="'+ID+'" t="'+self.Input.get()+'" />\0')
		Writer = open('log.txt','a')
		Writer.write("[You] > " + self.Input.get() + "\n")
		Writer.close()
		if len(self.Input.get()) > 10:
			self.Respond.insert(END, "[You]: " + self.Input.get() + "\n\n")
		else: self.Respond.insert(END, "[You]: " + self.Input.get() + "\n\n")
		self.Messages += 1
		if self.Messages > 10:
			self.Messages = 0
			self.Respond.delete(1.0, END)
		else: self.Input.delete(0, END)
	def getL5(self):
		PixelNoise = open('./_l5/' + self.Attributes['p'] + '.l5','r')
		l5 = {}
		Ivalue = int(self.Attributes['i']) % 10000
		p_x = Ivalue % 100
		p_y = int(math.floor(Ivalue / 100))
		for iValue in PixelNoise:
			pixel,value = iValue.strip().split(':')
			l5[pixel] = value
		PixelNoise.close()
		return l5[str(p_x)+','+str(p_y)]
	def getBetween(self,strSource, strStart,strEnd):
		start = strSource.find(strStart) + len(strStart)
		end = strSource.find(strEnd,start)
		return strSource[start:end]
xKonClient()
