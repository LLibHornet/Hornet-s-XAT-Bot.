<?php

$die = function ($who, $message, $type) {

    $bot = actionAPI::getBot();
    //TODO kill this bot
};
