<?php

$onDone = function ($array) {

    $bot = actionAPI::getBot();
    $bot->done = true;
};
