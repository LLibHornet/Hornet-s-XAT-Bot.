<?php

$onDup = function () {
    die();
};
