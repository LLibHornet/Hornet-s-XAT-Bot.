<?php

$onBlast = function ($array) {

};
