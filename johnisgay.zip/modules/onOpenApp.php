<?php

$onOpenApp = function ($who, $app) {

};
