<?php

$onPC = function ($who, $message) {

};
