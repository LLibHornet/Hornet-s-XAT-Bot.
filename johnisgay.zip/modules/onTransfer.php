<?php
$onTransfer = function ($from, $to, $xats, $days, $message) {
    //TODO process transfer
    return;
};
