<?php

$onMessage = function ($who, $message) {

};
