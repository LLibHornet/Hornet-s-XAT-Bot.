<?php

$onLogout = function ($array) {

};
