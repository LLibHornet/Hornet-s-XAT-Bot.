<?php

$onPM = function ($who, $message) {

};
