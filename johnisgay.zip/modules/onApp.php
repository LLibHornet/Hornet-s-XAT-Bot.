<?php

$onApp = function ($who, $app, $elements) {
    switch ($app) {
        case 10000: //Example stub for doodle

        break;
    }
};
