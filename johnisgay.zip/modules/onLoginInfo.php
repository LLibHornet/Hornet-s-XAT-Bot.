<?php

$onLoginInfo = function ($array) {

};
