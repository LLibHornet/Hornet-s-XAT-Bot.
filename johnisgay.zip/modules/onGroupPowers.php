<?php

$onGroupPowers = function ($array) {

};
