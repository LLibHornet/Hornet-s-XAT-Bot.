<?php

$onOldMessage = function ($who, $message) {

};
