#TODO list
##Commands
allmissing,
everymissing
twitter
clear
countdown
scramble
hangman
google
hasmost
userinfo
horoscope
lastseen
weather
love
power [enable/disable/clear/list]
search
edit
staff
kickall
chatinfos
rank
game
pool
history
getmain

##Features (pending database connection)
Alias'
Responses
Minranks
combine "ban/unban" commands with alias